<?php

   ini_set('display_errors', 1);
   ini_set('display_startup_errors', 1);
   error_reporting(E_ALL);
   
   // Include config file
   require_once 'db.php';
   
   // Define variables and initialize with empty values
   $username = $password = $confirm_password = "";
   $username_err = $password_err = $confirm_password_err = "";
    
   // Processing form data when form is submitted
   if(isset($_POST["username"])){
       // Validate username
       if(empty(trim($_POST["username"]))){
           $username_err = "Please enter a username.";
       } else{
           // Prepare a select statement
           $sql = "SELECT id FROM users WHERE username = ?";
           
           if($stmt = mysqli_prepare($link, $sql)){
               // Bind variables to the prepared statement as parameters
               mysqli_stmt_bind_param($stmt, "s", $param_username);
               
               // Set parameters
               $param_username = trim($_POST["username"]);
               
               // Attempt to execute the prepared statement
               if(mysqli_stmt_execute($stmt)){
                   /* store result */
                   mysqli_stmt_store_result($stmt);
                   
                   if(mysqli_stmt_num_rows($stmt) == 1){
                       print "<script>alert('This username is already taken.');</script>";
                   } else{
                       $username = trim($_POST["username"]);
                   }
               } else{
                   echo "Oops! Something went wrong. Please try again later.";
               }
           }
            
           // Close statement
           mysqli_stmt_close($stmt);
       }
       
       // Validate password
       if(empty(trim($_POST['password']))){
           $password_err = "Please enter a password.";     
       } else{
           $password = trim($_POST['password']);
       }
       
       
       // Check input errors before inserting in database
       if(empty($username_err)){
           
           // Prepare an insert statement
           $sql = "INSERT INTO users (username, password, firstname, secondname, phone, email, voter_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
            
           if($stmt = mysqli_prepare($link, $sql)){
               // Bind variables to the prepared statement as parameters
               mysqli_stmt_bind_param($stmt, "ssssssi", $param_username, $param_password, $param_fname, $param_sname, $param_phone, $param_email, $param_vote);
               
               // Set parameters
               $param_username = $username;
               $param_password = md5($password); // Creates a password hash
               $param_fname = $_POST['fname'];
               $param_sname = $_POST['sname'];
               $param_phone = $_POST['phone'];
               $param_email = $_POST['email'];
               $param_vote = $_POST['vid'];
               
               // Attempt to execute the prepared statement
               if(mysqli_stmt_execute($stmt)){
   
                 // Send Email
   
                 $msg = "welcome on board $param_fname $param_sname, this are the information you created your account with: "."\r\n".
                 "username: $param_username"."\r\n".
                 "Password: $password"."\r\n".
                 "Phone: $param_phone"."\r\n".
                 "email: $param_email"."\r\n".
                 "ID: $param_vote"."\r\n".
                 "Growth is waiting for you see you soon !";
   
                   $msg = wordwrap($msg,70);
   
                   if  (!mail($param_email, "Welcome on board $param_fname $param_sname", $msg))
                   {
                     // Mohamed, what you want to do when email not sent!
   
                     echo "Something went wrong with email. but your accoun is created.";
                   }
   
                   // Redirect to login page
                   header("location: Login.php");
   
               } else{
                   echo "Something went wrong. Please try again later.";
               }
           }
            
           // Close statement
           mysqli_stmt_close($stmt);
       }
       
       // Close connection
       mysqli_close($link);
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>InvestPlanners - Blessed Family</title>
      <!-- Bootstrap -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/overwrite.css">
      <link href="css/animate.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" />
      <link href="css/style1.css" rel="stylesheet" />
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
      <style>
         .error {color: #FF0000;}
      </style>
   </head>
   <body>
      <header id="header">
         <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">InvestPlanners</a>
               </div>
               <div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">
                     <li class="active"><a href="index.php#header">Home</a></li>
                     <li><a href="index.php#feature">Mission</a></li>
                     <li><a href="index.php#pricing">Packages</a></li>
                     <li><a href="Login.php">login</a></li>
                     <li><a href="Register.php">Register</a></li>
                     <li><a href="index.php#contact">Contact</a></li>
                  </ul>
               </div>
            </div>
            <!--/.container-->
         </nav>
         <!--/nav-->    
      </header>
      <!--/header-->  
      <div id="feature">
         <div class="container">
            <div class="row">
               <form id="Register" method="post" action="">
                  <div class="imgcontainer">
                     <img src="img/avatar.png" alt="Avatar" class="avatar">
                  </div>
                  <div class="container">
                     <p><span class="error"> * required field.</span></p>
                     <label><b>First Name</b></label>
                     <input type="text" placeholder="Enter First Name" name="fname"  >
                     <label><b>Second Name</b></label>
                     <input type="text" placeholder="Enter Second Name" name="sname" required >
                     <label><b>E-mail</b></label>
                     <input type="text" placeholder="Enter Email" name="email" required >
                     <label ><b>phone</b></label>
                     <input type="text" placeholder="Enter phone" name="phone" required >
                     <label><b>User Name</b></label>
                     <input type="text" placeholder="Enter Username" name="username" required >
                     <label><b>Password</b></label>
                     <input type="password" placeholder="Enter Password" name="password" required >
                     <label><b>Voter's ID</b></label>
                     <input type="text" placeholder="Enter Voter's ID" name="vid" required >
                     <button type="submit" name= "submit" value = "Submit">Register </button>
                     <label>
                     <input type="checkbox" checked="checked" name="remember"> Remember me
                     </label>
                  </div>
                  <div class="container" style="background-color:#f1f1f1">
                     <button type="button" class="cancelbtn">Cancel</button>
                     <span class="psw">Forgot <a href="#">password?</a></span>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <footer>
         <div class="text-center">
            <div class="copyright">
               &copy; 2018 <a target="_blank" href="" title="Free Twitter Bootstrap WordPress Themes and HTML templates">InvestPlanners</a>. All Rights Reserved.
            </div>
            <!-- 
               All links in the footer should remain intact. 
               Licenseing information is available at: http://bootstraptaste.com/license/
               You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Bikin
               -->
         </div>
      </footer>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="js/jquery-2.1.1.min.js"></script>    
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.min.js"></script> 
      <script src="js/parallax.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/fliplightbox.min.js"></script>
      <script src="js/functions.js"></script>
      <script>
         wow = new WOW(
          {
         
          } ) 
          .init();
      </script> 
   </body>
</html>

