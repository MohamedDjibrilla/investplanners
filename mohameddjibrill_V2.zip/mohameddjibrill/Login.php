<?php

   session_start();

   if (isset($_SESSION["user_id"]))
   {
     header("location:Dashboarduser.php");
     exit;
   }
   
       require_once('db.php');
       if (isset($_POST["uname"])){
           $res = mysqli_query($link, "SELECT * FROM users WHERE username LIKE '" . $_POST["uname"] . "' and password LIKE '". md5($_POST["psw"]) . "'");
           $row = mysqli_fetch_array($res);
           if(is_array($row)){
               
               $_SESSION["user_id"] = $row['id'];
               header("location:Dashboarduser.php");
               exit;
           }
           else{
               $message = "Invalid Username or Password!";
           }
       }
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>InvestPlanners - Blessed Family</title>
      <!-- Bootstrap -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/overwrite.css">
      <link href="css/animate.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" />
      <link href="css/style1.css" rel="stylesheet" />
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <header id="header">
         <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">InvestPlanners</a>
               </div>
               <div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">
                     <li class="active"><a href="index.php#header">Home</a></li>
                     <li><a href="index.php#feature">Mission</a></li>
                     <li><a href="index.php#pricing">Packages</a></li>
                     <li><a href="Login.php">Login</a></li>
                     <li><a href="Register.php">Register</a></li>
                     <li><a href="index.php#contact">Contact</a></li>
                  </ul>
               </div>
            </div>
            <!--/.container-->
         </nav>
         <!--/nav-->    
      </header>
      <!--/header-->  
      <div id="feature">
         <div class="container">
            <div class="row">
               <form action="" method="post">
                  <div class="imgcontainer">
                     <img src="img/avatar.png" alt="Avatar" class="avatar">
                  </div>
                  <?php if(isset($message)){echo $message;} ?>
                  <div class="container">
                     <label for="uname"><b>Username</b></label>
                     <input type="text" placeholder="Enter Username" name="uname" required>
                     <label for="psw"><b>Password</b></label>
                     <input type="password" placeholder="Enter Password" name="psw" required>
                     <button type="submit" onclick="">Login</button>
                     <label>
                     <input type="checkbox" checked="checked" name="remember"> Remember me
                     </label>
                  </div>
                  <div class="container" style="background-color:#f1f1f1">
                     <button type="button" class="cancelbtn">Cancel</button>
                     <span class="psw">Forgot <a href="#">password?</a></span>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <div class="text-center">
         <div class="copyright">
            &copy; 2018 <a target="_blank" href="" title="Free Twitter Bootstrap WordPress Themes and HTML templates">InvestPlanners</a>. All Rights Reserved.
         </div>
      </div>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="js/jquery-2.1.1.min.js"></script>    
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.min.js"></script> 
      <script src="js/parallax.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/fliplightbox.min.js"></script>
      <script src="js/functions.js"></script>
      <script>
         wow = new WOW(
          {
         
          } ) 
          .init();
      </script> 
   </body>
</html>

