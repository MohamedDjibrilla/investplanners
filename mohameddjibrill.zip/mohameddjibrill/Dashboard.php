

<?php    

require('db.php');    
$user = mysqli_query($link, "SELECT * FROM users");    
$firstLevel = mysqli_query($link, "SELECT * FROM firstlevel");    
$secondLevel = mysqli_query($link, "SELECT * FROM secondlevel");    
$recomit = mysqli_query($link, "SELECT * FROM secondlevel");

?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->    
      <title>InvestPlanners - Blessed Family</title>
      <!-- Bootstrap -->    
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/overwrite.css">
      <link href="css/animate.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" />
      <link href="css/styles.css" rel="stylesheet">
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->    <!--[if lt IE 9]>    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>    <![endif]-->  
   </head>
   <body>
      <header id="header">
         <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
               <div class="navbar-header">                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">                        <span class="sr-only">Toggle navigation</span>                        <span class="icon-bar"></span>                        <span class="icon-bar"></span>                        <span class="icon-bar"></span>                    </button>                    <a class="navbar-brand" href="index.html">InvestPlanners</a>                </div>
               <div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">
                     <li class="active"><a href="#index.htmlheader">Home</a></li>
                     <li><a href="#index.htmlfeature">Mission</a></li>
                     <li><a href="#index.htmlpricing">Packages</a></li>
                     <li><a href="Login.html">login</a></li>
                     <li><a href="Register.html">Register</a></li>
                     <li><a href="index.html#contact">Contact</a></li>
                  </ul>
               </div>
            </div>
            <!--/.container-->        
         </nav>
         <!--/nav-->		    
      </header>
      <!--/header-->			
      <div class="page-content">
      <div class="row">
      <div class="col-md-2">
         <div class="sidebar content-box" style="display: block;">
            <div class="imgcontainer1">                          <img src="img/avatar.png" alt="Avatar" class="avatar">                </div>
            <ul class="nav">
               <!-- Main menu -->                    
               <li><i class="glyphicon glyphicon-home"></i> Username </a></li>
            </ul>
         </div>
      </div>
      <div class="col-md-10">
      <div class="row">
         <div class="col-md-6">
            <div class="content-box-large">
               <div class="panel-heading">
                  <div class="panel-title">Basic Table</div>
                  <div class="panel-options">								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>							</div>
               </div>
               <div class="panel-body">
                  <table class="table">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>First Name</th>
                           <th>Last Name</th>
                           <th>Username</th>
                        </tr>
                     </thead>
                     <tbody>                              <?php                              $n = 1;                                while ($row = mysqli_fetch_array($user)){                                    echo "<tr>";                                    echo "<td>" . $n++ . "</td>";                                    echo "<td>" . $row['firstname'] . "</td>";                                    echo "<td>" . $row['secondname'] . "</td>";                                    echo "<td>" . $row['username'] . "</td>";                                    echo "</tr>";                                }                              ?>				              </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="content-box-large">
               <div class="panel-heading">
                  <div class="panel-title">Striped Rows</div>
                  <div class="panel-options">								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>							</div>
               </div>
               <div class="panel-body">
                  <table class="table table-striped">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Seed</th>
                           <th>Seed ID</th>
                           <th>Sustainability</th>
                           <th>Sustainability ID</th>
                           <th>Date & Time</th>
                        </tr>
                     </thead>
                     <tbody>                              <?php                              $n = 1;                                  while ($row = mysqli_fetch_array($firstLevel)){                                      echo "<tr>";                                      echo "<td>" . $n++ . "</td>";                                      echo "<td>" . $row['seed'] . "</td>";                                      echo "<td>" . $row['seedID'] . "</td>";                                      echo "<td>" . $row['sustainability'] . "</td>";                                      echo "<td>" . $row['sustainabilityID'] . "</td>";                                      echo "<td>" . $row['date_time'] . "</td>";                                      echo "</tr>";                                  }                              ?>				              </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-6">
            <div class="content-box-large">
               <div class="panel-heading">
                  <div class="panel-title">Border Table</div>
                  <div class="panel-options">								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>							</div>
               </div>
               <div class="panel-body">
                  <table class="table table-bordered">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Recommit</th>
                           <th>Recommit ID</th>
                           <th>Date & Time</th>
                        </tr>
                     </thead>
                     <tbody>                              <?php                              $n = 1;                                  while ($row = mysqli_fetch_array($secondLevel)){                                      echo "<tr>";                                      echo "<td>" . $n++ . "</td>";                                      echo "<td>" . $row['recommit'] . "</td>";                                      echo "<td>" . $row['recommitID'] . "</td>";                                      echo "<td>" . $row['date_time'] . "</td>";                                      echo "</tr>";                                  }                              ?>				              </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="content-box-large">
               <div class="panel-heading">
                  <div class="panel-title">Hover Rows</div>
                  <div class="panel-options">								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>							</div>
               </div>
               <div class="panel-body">
                  <table class="table table-hover">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Recommit</th>
                           <th>Recommit ID</th>
                           <th>Date & Time</th>
                        </tr>
                     </thead>
                     <tbody>                              <?php                                    $n = 1;                                  while ($row = mysqli_fetch_array($recomit)){                                      echo "<tr>";                                      echo "<td>" . $n++ . "</td>";                                      echo "<td>" . $row['recommit'] . "</td>";                                      echo "<td>" . $row['recommitID'] . "</td>";                                      echo "<td>" . $row['date_time'] . "</td>";                                      echo "</tr>";                                  }                              ?>				              </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
      <div class="text-center">
         <div class="copyright">				&copy; 2018 <a target="_blank" href="" title="Free Twitter Bootstrap WordPress Themes and HTML templates">InvestPlanners</a>. All Rights Reserved.			</div>
         <!--                 All links in the footer should remain intact.                 Licenseing information is available at: http://bootstraptaste.com/license/                You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Bikin            -->		
      </div>
      </footer>    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->    <script src="js/jquery-2.1.1.min.js"></script>		    <!-- Include all compiled plugins (below), or include individual files as needed -->    <script src="js/bootstrap.min.js"></script>		<script src="js/parallax.min.js"></script>	<script src="js/wow.min.js"></script>	<script src="js/jquery.easing.min.js"></script>	<script type="text/javascript" src="js/fliplightbox.min.js"></script>	<script src="js/functions.js"></script>	<script>	wow = new WOW(	 {			}	) 		.init();	</script>	  
   </body>
</html>

