
<?php

   session_start();

   if (!isset($_SESSION["user_id"]))
   {
     header("location:Login.php");
     exit;
   }
   
   require_once 'db.php';
   
       $res = mysqli_query($link, "SELECT * FROM users WHERE id='" . $_SESSION["user_id"] . "'");
       $row = mysqli_fetch_array($res);
   
       $_SESSION['transl1'] = false;
   
       $mydate=getdate(date("U"));
   
       $dateS = $mydate['mday'] . "-" . $mydate['mon'] . "-" . $mydate['year'];;
       if (isset($_POST['seed']) && isset($_POST['transaction']) && isset($_POST['sustainability'])){
           $sql = "INSERT INTO `transaction1`(`seed`, `transaction_number`, `sustainability_fee`, `date`, `user_id`) VALUES ('" . $_POST['seed'] . "', '". $_POST['transaction'] ."', '" . $_POST['sustainability'] . "', '" . $dateS ."', '" . $_SESSION["user_id"] . "')";
           mysqli_query($link, $sql);
           $_SESSION['transl1'] = true;
       }
   
        //if ($_SESSION['transl1'] === true){
           if (isset($_POST['recommit']) && isset($_POST['recommitid'])){
               $sql = "INSERT INTO `secondlevel`(`recommit`, `recommitID`, `date_time`, `user_id`) VALUES ('" . $_POST['recommit'] . "', '" . $_POST['recommitid'] . "', '" . $dateS . "', '" . $_SESSION["user_id"] . "')";
               mysqli_query($link, $sql);
               
           }
       //}
   
       $trans1 = mysqli_query($link, "SELECT * FROM transaction1 WHERE user_id  = " . $row['id']);
       $trans = mysqli_query($link, "SELECT * FROM secondlevel WHERE user_id = " . $row['id']);
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>InvestPlanners - Blessed Family</title>
      <!-- Bootstrap -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/animate.css">
      <link rel="stylesheet" href="css/overwrite.css">
      <link href="css/animate.min.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet" />
      <link href="css/styles.css" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <header id="header">
         <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
               <div class="navbar-header">
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">InvestPlanners</a>
               </div>
               <div class="collapse navbar-collapse navbar-right">
                  <ul class="nav navbar-nav">
                     <li class="active"><a href="#index.htmlheader">Home</a></li>
                     <li><a href="#index.htmlfeature">Mission</a></li>
                     <li><a href="#index.htmlpricing">Packages</a></li>
                     <li><a href="Logout.php">Logout</a></li>
                     <li><a href="index.html#contact">Contact</a></li>
                  </ul>
               </div>
            </div>
            <!--/.container-->
         </nav>
         <!--/nav-->   
      </header>
      <!--/header--> 
      <div class="page-content">
         <div class="row">
            <div class="col-md-2">
               <div class="sidebar content-box" style="display: block;">
                  <div class="imgcontainer1">
                     <img src="img/avatar.png" alt="Avatar" class="avatar">
                  </div>
                  <ul class="nav">
                     <!-- Main menu -->
                     <li><i class="glyphicon glyphicon-home"></i> Username : <?php echo ucwords($row['username']) ?></a></li>
                  </ul>
               </div>
            </div>
            <div class="col-md-10">
               <div class="content-box-large">
                  <div class="panel-heading">
                     <div class="panel-title">INFORMATION PANE <?php echo "</br>First & Last name : " . ucwords($row['firstname']). " " . ucwords($row['secondname']) ?></div>
                     <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                        <a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                     </div>
                  </div>
                  <div class="panel-body">
                     <div id="hero-area" style="height: 230px;"></div>
                  </div>
               </div>
               <div class="content-box-large">
                  <div class="panel-heading">
                     <div class="panel-title">FIRST LEVEL</div>
                     <div class="panel-options">
                        <a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                        <a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                     </div>
                     <div class="panel-body">
                        <table>
                           <tbody>
                              <tr>
                                 <form action="" method="post">
                                    <td><input type="text" placeholder="seed" name="seed" required></td>
                                    <td><input type="text" placeholder="transaction number" name="transaction" required></td>
                                    <td><input type="text" placeholder="sustainability fee" name="sustainability" required></td>
                                    <td><button type="submit" onclick="">Submit Transaction1</button></td>
                                 </form>
                              </tr>
                           </tbody>
                        </table>
                        <table class="table table-bordered" id="tbl_posts">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th>seed</th>
                                 <th>transaction number</th>
                                 <th>sustainability fee</th>
                                 <th>Date</th>
                              </tr>
                           </thead>
                           <tbody id="tbl_posts_body">
                              <?php
                                 $n = 1;
                                 while ($row = mysqli_fetch_array($trans1)){
                                     echo "<tr>";
                                     echo "<td>" . $n++ . "</td>";
                                     echo "<td>" . $row['seed'] . "</td>";
                                     echo "<td>" . $row['transaction_number'] . "</td>";
                                     echo "<td>" . $row['sustainability_fee'] . "</td>";
                                     echo "<td>" . $row['date'] . "</td>";
                                     echo "</tr>";
                                 }
                                 ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
               <div class="panel-body">
                  <div id="hero-graph" style="height: 230px;"></div>
               </div>
            </div>
            <div class="content-box-large">
               <div class="panel-heading">
                  <div class="panel-title">SECOND LEVEL</div>
                  <div class="panel-options">
                     <a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
                     <a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
                  </div>
                  <div class="panel-body">
                     <table>
                        <tbody>
                           <tr>
                              <form action="" method="post">
                                 <td><input type="text" placeholder="Recommit" name="recommit" required></td>
                                 <td><input type="text" placeholder="Recommit ID" name="recommitid" required></td>
                                 <td><button type="submit" onclick="" <?php if ($_SESSION['transl1'] === false) { echo "disabled"; } ?> id="trans">Submit Transaction</button></td>
                              </form>
                           </tr>
                        </tbody>
                     </table>
                     <table class="table table-bordered" id="tbl_posts">
                        <thead>
                           <tr>
                              <th>#</th>
                              <th>Recommit</th>
                              <th>Recommit ID</th>
                              <th>Date</th>
                           </tr>
                        </thead>
                        <tbody id="tbl_posts_body">
                           <?php
                              $n = 1;
                              while ($row = mysqli_fetch_array($trans)){
                                  echo "<tr>";
                                  echo "<td>" . $n++ . "</td>";
                                  echo "<td>" . $row['recommit'] . "</td>";
                                  echo "<td>" . $row['recommitID'] . "</td>";
                                  echo "<td>" . $row['date_time'] . "</td>";
                                  echo "</tr>";
                              }
                              ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <footer>
         <div class="text-center">
            <div class="copyright">
               &copy; 2018 <a target="_blank" href="" title="Free Twitter Bootstrap WordPress Themes and HTML templates">InvestPlanners</a>. All Rights Reserved.
            </div>
            <!-- 
               All links in the footer should remain intact. 
               Licenseing information is available at: http://bootstraptaste.com/license/
               You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Bikin
               -->
         </div>
      </footer>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="js/jquery-2.1.1.min.js"></script>    
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.min.js"></script> 
      <script src="js/parallax.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/fliplightbox.min.js"></script>
      <script src="js/functions.js"></script>
      <script>
         wow = new WOW(
          {
         
           } ) 
           .init();
      </script> 
   </body>
</html>

